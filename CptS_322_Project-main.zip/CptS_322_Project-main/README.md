# CptS_322_Project
We are creating a Restaurant Automation app using React and ASP.net API.

Samuel Jacobi
11755772
samuel.jacobi@wsu.edu

Wongyu Hwang
011604237
wongyu.hwang@wsu.edu

Albert Lucas
11525593
albert.lucas@wsu.edu

Nicholas Kraabel
011713809
nicholas.kraabel@wsu.edu

Jiwoo Kim
011643030
jiwoo.kim2@wsu.edu

Ryan Bean
11670335
Ryan.bean@wsu.edu
